"""One-shot migration checks; no new target collection or evidence mutation."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import time

ROOT = Path('/data2/neural-shrimp')
AUDIT = Path('/data2/neural-shrimp-migration-20260913/audit-001')
PYTHON = Path('/data2/neural-shrimp-runtime/python/cpython-3.12.14-linux-x86_64-gnu/bin/python3.12')
AUDIT.mkdir(mode=0o700)
os.chdir(ROOT)
env = dict(os.environ)
env.update(PYTHONDONTWRITEBYTECODE='1', MPLCONFIGDIR=str(AUDIT / 'matplotlib'),
           PIP_CACHE_DIR='/data2/neural-shrimp-runtime/pip-cache',
           OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
           NUMEXPR_NUM_THREADS='1')
record = {
    'scope': 'Server migration and saved-evidence replay; no new target integrations',
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'research_commit': '84db65338a055a855364098bb392d419e9053b19',
    'platform': platform.platform(), 'machine': platform.machine(),
    'bootstrap_python': sys.version, 'project_root': str(ROOT),
    'system_python_not_modified': True,
    'thread_limits': {k: env[k] for k in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS',
                                        'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS']},
    'commands': [],
}


def save():
    (AUDIT / 'checks.json').write_text(json.dumps(record, indent=2) + '\n')


def run(name, argv, required=False):
    start = time.monotonic()
    with (AUDIT / f'{name}.stdout.txt').open('x') as out, (AUDIT / f'{name}.stderr.txt').open('x') as err:
        p = subprocess.run(argv, cwd=ROOT, env=env, stdout=out, stderr=err)
    item = {'name': name, 'argv': argv, 'exit_code': p.returncode,
            'seconds': time.monotonic() - start,
            'stdout': f'{name}.stdout.txt', 'stderr': f'{name}.stderr.txt'}
    record['commands'].append(item)
    save()
    print(f'{name}: exit {p.returncode}, {item["seconds"]:.1f}s', flush=True)
    if required and p.returncode:
        raise SystemExit(f'Required setup/transfer check failed: {name}')


assert sys.version_info[:3] == (3, 12, 14)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == record['research_commit']
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
save()
run('system-python', ['/usr/bin/python3', '--version'], True)
run('git-object-integrity', ['git', 'fsck', '--full', '--no-reflogs'], True)
blocks = re.findall(r'```sh\n(.*?)```', (ROOT / 'SERVER-HANDOFF.md').read_text(), re.S)
block = next(b for b in blocks if b.startswith("python - <<'PY'"))
code = block.split('\n', 1)[1].rsplit('\nPY', 1)[0]
run('evidence-checksums', [str(PYTHON), '-c', code], True)
assert not (ROOT / '.venv').exists(), 'Do not replace an existing virtual environment'
run('create-venv', [str(PYTHON), '-m', 'venv', str(ROOT / '.venv')], True)
venv = str(ROOT / '.venv/bin/python')
run('locked-dependencies', [venv, '-m', 'pip', 'install', '--require-hashes', '-r', 'requirements.lock'], True)
run('editable-project', [venv, '-m', 'pip', 'install', '--no-deps', '-e', '.'], True)
run('dependency-consistency', [venv, '-m', 'pip', 'check'], True)
run('installed-packages', [venv, '-m', 'pip', 'freeze'], True)
run('scientific-build-config', [venv, '-c',
    'import sys,numpy,scipy; print(sys.version); print("numpy",numpy.__version__); '
    'numpy.show_config(); print("scipy",scipy.__version__); scipy.show_config()'], True)
run('unit-tests', [venv, '-m', 'pytest', '-q'])
run('isolated-source-bundle', [venv, 'tools/check_information_bundle.py'])
run('platform-diagnostic', [venv, 'tools/audit_information_platform.py',
    'evidence/EXP-008/attempt-001', '--out', str(AUDIT / 'platform.json')])
run('frozen-verifier', [venv, 'tools/run_hopfield_information.py', 'verify',
    '--output', 'evidence/EXP-008/attempt-001'])
run('evidence-checksums-after', [str(PYTHON), '-c', code], True)
run('tracked-status-after', ['git', 'status', '--porcelain'], True)
assert not (AUDIT / 'tracked-status-after.stdout.txt').read_text().strip(), 'Tracked checkout changed'
record['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
record['complete'] = True
record['interpretation'] = ('Completion of this migration audit is not a general numerical reproduction claim. '
                            'Read each exit status and platform comparison, including retained failures.')
save()
print('Audit complete; retained every command result. No new experiment attempt was created.', flush=True)
